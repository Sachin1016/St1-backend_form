exports.div = function(a,b){
    if(a>b){
        return a/b;
    } 
    else{
        return b/a;
    }
}
exports.NODivBy2 = function(n){
    if(n%2==0){
        return "Number is Divisible by 2";
    }
    else{
        return "Not";
    }
}
// var c = require('./one');
// console.log("Addition: "+c.add(2,3));
// console.log("Multiplication: "+c.mult(2,3));

// var d = require('./two');
// console.log("Division: "+d.div(4,2));
// console.log("Division2: "+d.div(2,4));
// console.log("No. div by 2 or not: "+d.NODivBy2(10));


// // what is the difference b/w architecture and platform ?

// var os = require('os');       
// console.log("Platform: "+os.platform());
// console.log("Architecture: "+os.arch());
// console.log(os.freemem()/1024/1024/1024);
// console.log(os.totalmem()/1024/1024/1024);
// console.log(os.networkInterfaces());



// console.log(os.cpus());

// var server = require('http');
// server.createServer(function(request,response){

//     if(request.url=='/'){
//         response.end("This is my Home Page");
//     }
//     else if(request.url=='/contact'){
//         response.end("This is my Contact Us Page");
//     }
//     else if(request.url=='/about'){
//         response.end("This is my About us Page");
//     }
//     else{
//         response.end("404 Error Page not found");
//     }

// }).listen(3000,"localhost",()=>{
//     console.log("Server is ready")
// });

// var http = require('http');
// var fs = require('fs');
// server.createServer(function (req, res) {
//   fs.readFile('file1.html', function(err, data) {
//     if(err)
//         return console.error('');

//         res.writeHead(200, {'setContent' : 'text/html'});
//         res.write(data);
//         res.end()
//   })
// }).listen(3001,"localhost", ()=>{
//     console.log("Server is ready Yooooo!!!")
// });

// -----------------------------------------------------------------------------------------------------------------------------------------



// const bodyParser = require('body-parser');
// const express = require('express');
// var app = express();
// app.get('/',function(req,res)
// {
    
//    // res.send("This is First Application of Express")
   
//    res.sendFile(__dirname+'/file1.html');
// })



// app.get('/Home',function(req,res)
// {
//     res.send("This is Home Application of Express")
// })




// app.get('/Contact',function(req,res)
// {
//     res.send("This is Contact Application of Express")
// })
// app.listen(3003,function(){
//     console.log("Server is running");
// });

// ------------------------------------------------------------------------------

// app.use(bodyParser.urlencoded({extended:true}))

// app.get('/',function(request,response){
//     response.sendFile(__dirname+'/file1.html')
// })
// app.post('/home',function(request,response){
//      var name = request.body.name;
//     // response.send("Your Name is="+name)
//     var a = Number(request.body.fno);
//     var b = Number(request.body.fno);

//     var c = a+b;
//     response.send("Sum of a and b = "+c);
// })
// app.listen(3010);

// const https=require("https");


// app.get("/",(req,res)=>{
//   const url="https://api.kanye.rest/";
//   https.get(url,(response)=>{
//     console.log(response.statusCode)
//     response.on("data",(d)=>{
//         var data=JSON.parse(d);
//         console.log(data);
//        res.send(data.quote);
//     })
//   })
// })
// app.listen(3010);





// ----------------------------------------------------   BEE ST1 PROJECT  ------------------------------------------------------------------------------------


var v = require('./average');
const fs = require('fs');
console.log("Grade: "+v.average(10,20,30,40,50));


const bodyParser = require('body-parser');
const express = require('express');
var app = express();

app.set('view engine','ejs');

app.use(bodyParser({extended:true}))
app.get('/',function(request,response){
  response.sendFile(__dirname+'/file1.html')
})
app.post('/home',function(request,response){ 
  var i =  request.body.name;
  

  // console.log(request.body.name)

  var userId = request.body.name[0];
  var username = request.body.name[1];
  var sub1 = Number(request.body.name[3]);
  var sub2 = Number(request.body.name[4]);
  var sub3 = Number(request.body.name[5]);
  var sub4 = Number(request.body.name[6]);
  var sub5 = Number(request.body.name[7]);

  var average = (sub1+sub2+sub3+sub4+sub5)/5;

  const data = {
    userId,
    username,
    average,
    sub1,
    sub2,
    sub3,
    sub4,
    sub5,
  }

  if(!fs.existsSync('data.json')){
    fs.closeSync(fs.openSync('data.json','w'));
  }

  const file = fs.readFileSync('data.json');

  if(file.length == 0){
    fs.writeFileSync("data.json",JSON.stringify([data]))
  }else{
    let json = JSON.parse(file.toString());
    console.log(json)
    json.push(data);
    fs.writeFileSync("data.json",JSON.stringify(json))
  }

  response.redirect('/displayData')
})

app.get('/displayData',(request,response)=>{
  const fileData = require('./data.json');

  console.log(fileData);

  let grades = [];
   

  fileData.forEach(({average,username,userId,sub1,sub2,sub3,sub4,sub5})=>{
    if(average>90){
       grades.push({grade:'A',average,username,userId,marks:[sub1,sub2,sub3,sub4,sub5]});
   }
   else if(average>80){
    grades.push({grade:'B',average,username,userId,marks:[sub1,sub2,sub3,sub4,sub5]});
   }
   else if(average>70){
    grades.push({grade:'C',average,username,userId,marks:[sub1,sub2,sub3,sub4,sub5]});
   }
   else if(average>60){
    grades.push({grade:'D',average,username,userId,marks:[sub1,sub2,sub3,sub4,sub5]});
   }
   else if(average>32){
    grades.push({grade:'E',average,username,userId,marks:[sub1,sub2,sub3,sub4,sub5]});
   }
   else{
    grades.push({grade:'F',average,username,userId,marks:[sub1,sub2,sub3,sub4,sub5]});
   }
  })

  response.render('data.ejs',{displayData:grades});

})
app.listen(3023,function(){
  console.log("SERVER IS RUNNING");
});


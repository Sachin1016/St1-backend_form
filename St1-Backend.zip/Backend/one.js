exports.hello = function(){
    return "hello";
}

exports.add = function(a, b){
    return a+b;
}

exports.mult =  function(a,b){
    return a*b;
}
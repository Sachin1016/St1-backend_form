exports.average = function(a,b,c,d,e){
     average = (a+b+c+d+e)/5;
     if(average>90){
        return "A";
     }
     else if(average>80){
        return "B";
     }
     else if(average>70){
        return "C";
     }
     else if(average>60){
        return "D";
     }
     else if(average>32){
        return "E";
     }
     else{
        return "F";
     }
}